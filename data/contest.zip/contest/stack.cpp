// #define LOCAL
#include <bits/stdc++.h>
using namespace std;

constexpr int MAXN = 2e5 + 5;
int n, tot;
int a[MAXN], ans[MAXN];

vector<int> G[MAXN];
int deg[MAXN];

int main() {
#ifndef LOCAL
    freopen("stack.in", "r", stdin);
    freopen("stack.out", "w", stdout);
#endif

    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n;
    for (int i = 1; i <= n; i++)
        cin >> a[i];

    stack<int> s;
    for (int i = 1; i <= n; i++) {
        int last = -1;
        while (s.size() > a[i] - 1) {
            last = s.top();
            s.pop();
        }
        if (last != -1) {
            G[i].push_back(last), deg[last]++;
            // cerr << i << " " << last << endl;
        }
        if (!s.empty()) {
            // cerr << s.top() << " " << i << endl;
            G[s.top()].push_back(i), deg[i]++;
        }
        // cerr << "---" << endl;
        s.push(i);
    }

    // for (int i = 1; i <= n; i++) {
    //     for (int v : G[i])
    //         cout << i << " " << v << endl;
    // }

    priority_queue<int, vector<int>, greater<int>> q;
    for (int i = 1; i <= n; i++)
        if (deg[i] == 0)
            q.push(i);

    while (!q.empty()) {
        int u = q.top();
        q.pop();
        ans[u] = ++tot;
        for (int v : G[u]) {
            deg[v]--;
            if (deg[v] == 0)
                q.push(v);
        }
    }

    for (int i = 1; i <= n; i++)
        cout << ans[i] << " ";

    return 0;
}