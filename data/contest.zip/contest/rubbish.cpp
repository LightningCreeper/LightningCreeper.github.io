#define LOCAL
#pragma GCC optimize(3)
#pragma GCC target("avx")
#pragma GCC optimize("Ofast")
#pragma GCC optimize("inline")
#pragma GCC optimize("-fgcse")
#pragma GCC optimize("-fgcse-lm")
#pragma GCC optimize("-fipa-sra")
#pragma GCC optimize("-ftree-pre")
#pragma GCC optimize("-ftree-vrp")
#pragma GCC optimize("-fpeephole2")
#pragma GCC optimize("-ffast-math")
#pragma GCC optimize("-fsched-spec")
#pragma GCC optimize("unroll-loops")
#pragma GCC optimize("-falign-jumps")
#pragma GCC optimize("-falign-loops")
#pragma GCC optimize("-falign-labels")
#pragma GCC optimize("-fdevirtualize")
#pragma GCC optimize("-fcaller-saves")
#pragma GCC optimize("-fcrossjumping")
#pragma GCC optimize("-fthread-jumps")
#pragma GCC optimize("-funroll-loops")
#pragma GCC optimize("-fwhole-program")
#pragma GCC optimize("-freorder-blocks")
#pragma GCC optimize("-fschedule-insns")
#pragma GCC optimize("inline-functions")
#pragma GCC optimize("-ftree-tail-merge")
#pragma GCC optimize("-fschedule-insns2")
#pragma GCC optimize("-fstrict-aliasing")
#pragma GCC optimize("-fstrict-overflow")
#pragma GCC optimize("-falign-functions")
#pragma GCC optimize("-fcse-skip-blocks")
#pragma GCC optimize("-fcse-follow-jumps")
#pragma GCC optimize("-fsched-interblock")
#pragma GCC optimize("-fpartial-inlining")
#pragma GCC optimize("no-stack-protector")
#pragma GCC optimize("-freorder-functions")
#pragma GCC optimize("-findirect-inlining")
#pragma GCC optimize("-fhoist-adjacent-loads")
#pragma GCC optimize("-frerun-cse-after-loop")
#pragma GCC optimize("inline-small-functions")
#pragma GCC optimize("-finline-small-functions")
#pragma GCC optimize("-ftree-switch-conversion")
#pragma GCC optimize("-foptimize-sibling-calls")
#pragma GCC optimize("-fexpensive-optimizations")
#pragma GCC optimize("-funsafe-loop-optimizations")
#pragma GCC optimize("inline-functions-called-once")
#pragma GCC optimize("-fdelete-null-pointer-checks")
#pragma GCC optimize(2)

#include <bits/stdc++.h>
using namespace std;

#include <bits/stdc++.h>
using namespace std;
static char buf[1000000], *p1 = buf, *p2 = buf, obuf[1000000], *p3 = obuf;
#define getchar() p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1000000, stdin), p1 == p2) ? EOF : *p1++
#define putchar(x) (p3 - obuf < 1000000) ? (*p3++ = x) : (fwrite(obuf, p3 - obuf, 1, stdout), p3 = obuf, *p3++ = x)
template <typename item>
inline void uread(register item &x) {
    x = 0;
    register char c = getchar();
    while (c < '0' || c > '9')
        c = getchar();
    while (c >= '0' && c <= '9')
        x = (x << 3) + (x << 1) + (c ^ 48), c = getchar();
}
static char cc[20];
template <typename item>
inline void uprint(register item x) {
    if (x == 0)
        putchar('0');
    register int len = 0;
    while (x)
        cc[len++] = x % 10 + '0', x /= 10;
    while (len--)
        putchar(cc[len]);
}

constexpr int MAXN = 2e5 + 5;

int n, q;
long long x[MAXN];

int main() {
#ifndef LOCAL
    freopen("rubbish.in", "r", stdin);
    freopen("rubbish.out", "w", stdout);
#endif

    uread(n), uread(q);
    for (int i = 1; i <= n; i++)
        uread(x[i]);

    for (int i = 1; i <= q; i++) {
        int opt, a, b, c, d;
        uread(opt);
        uread(a);
        uread(b);
        if (opt == 1) {
            uread(c);
            for (int j = a; j <= b; j++)
                x[j] += c;
        } else if (opt == 2) {
            uread(c), uread(d);
            if (d > b)
                for (int j = a, k = c; j <= b; j++, k++)
                    x[j] = x[k];
            else
                for (int j = b, k = d; j >= a; j--, k--)
                    x[j] = x[k];
        } else {
            long long ans = 0;
            for (int j = a; j <= b; j++)
                ans += x[j];
            uprint(ans);
            putchar('\n');
        }
    }
    fwrite(obuf, p3 - obuf, 1, stdout);
    // cerr << 1e3 * clock() / CLOCKS_PER_SEC << "ms" << endl;

    return 0;
}