#define LOCAL

#include <bits/stdc++.h>
using namespace std;

constexpr int MOD1 = 1e9 + 7;
constexpr int MOD2 = 1e9 + 9;
constexpr int MAXN = 2e5 + 5;

int n, q;
string s;
int hsh1[MAXN][26], hsh2[MAXN][26], p1[MAXN], p2[MAXN];

int calc(int x) {
    while (x >= MOD1)
        x -= MOD1;
    return x;
}

int calc2(int x) {
    while (x >= MOD2)
        x -= MOD2;
    return x;
}

int main() {
#ifndef LOCAL
    freopen("method.in", "r", stdin);
    freopen("method.out", "w", stdout);
#endif

    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> q >> s;
    s = " " + s;
    p1[0] = 1;
    p2[0] = 1;
    for (int i = 1; i <= n; i++) {
        for (int j = 0; j < 26; j++) {
            hsh1[i][j] = calc(1ll * hsh1[i - 1][j] * 2 + (s[i] == ('a' + j)));
            hsh2[i][j] = calc2(1ll * hsh2[i - 1][j] * 2 + (s[i] == ('a' + j)));
        }
        p1[i] = p1[i - 1] * 2 % MOD1;
        p2[i] = p2[i - 1] * 2 % MOD2;
    }

    for (int i = 1; i <= q; i++) {
        int l1, r1, l2, r2;
        cin >> l1 >> r1 >> l2 >> r2;
        vector<int> x1, y1, x2, y2;
        for (int j = 0; j < 26; j++) {
            x1.push_back(calc(hsh1[r1][j] - 1ll * hsh1[l1 - 1][j] * p1[r1 - l1 + 1] % MOD1 + MOD1));
            y1.push_back(calc(hsh1[r2][j] - 1ll * hsh1[l2 - 1][j] * p1[r2 - l2 + 1] % MOD1 + MOD1));
            x2.push_back(calc2(hsh2[r1][j] - 1ll * hsh2[l1 - 1][j] * p2[r1 - l1 + 1] % MOD2 + MOD2));
            y2.push_back(calc2(hsh2[r2][j] - 1ll * hsh2[l2 - 1][j] * p2[r2 - l2 + 1] % MOD2 + MOD2));
        }
        sort(x1.begin(), x1.end());
        sort(y1.begin(), y1.end());
        sort(x2.begin(), x2.end());
        sort(y2.begin(), y2.end());
        // for (int i : x1)
        //     cerr << i << " ";
        // cerr << endl;
        // for (int i : y1)
        //     cerr << i << " ";
        // cerr << endl;
        // for (int i : x2)
        //     cerr << i << " ";
        // cerr << endl;
        // for (int i : y2)
        //     cerr << i << " ";
        // cerr << endl;
        // cerr << endl;
        if (x1 == y1 && x2 == y2)
            cout << "Yes" << endl;
        else
            cout << "No" << endl;
    }

    return 0;
}